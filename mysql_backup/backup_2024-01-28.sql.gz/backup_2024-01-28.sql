-- MySQL dump 10.13  Distrib 8.0.34-26, for Linux (x86_64)
--
-- Host: 192.168.100.20    Database: smsdb
-- ------------------------------------------------------
-- Server version	8.0.34-26.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `applicationList`
--

DROP TABLE IF EXISTS `applicationList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicationList` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_code`
--

DROP TABLE IF EXISTS `application_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_code` (
  `id` varchar(5) NOT NULL,
  `application` varchar(66) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `application` (`application`),
  KEY `id_2` (`id`),
  KEY `application_2` (`application`),
  KEY `id_3` (`id`,`application`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bananaapi-number`
--

DROP TABLE IF EXISTS `bananaapi-number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bananaapi-number` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` bigint NOT NULL,
  `country_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'any',
  `taked` tinyint NOT NULL DEFAULT '0',
  `createdTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `multiapp` tinyint NOT NULL DEFAULT '0',
  `taked_time` timestamp NULL DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  `is_finished` tinyint NOT NULL DEFAULT '0',
  `is_finished_time` timestamp NULL DEFAULT NULL,
  `requested` int NOT NULL DEFAULT '0',
  `release_time` timestamp NULL DEFAULT NULL,
  `flag` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phone_number` (`phone_number`),
  KEY `country_code` (`country_code`),
  KEY `source` (`source`),
  KEY `application` (`application`),
  KEY `taked` (`taked`),
  KEY `createdTime` (`createdTime`),
  KEY `flag` (`flag`),
  KEY `idx_fk_foreignapiservice` (`application`,`country_code`),
  KEY `idx_fk_countries_control` (`country_code`,`source`)
) ENGINE=InnoDB AUTO_INCREMENT=56806394 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bananaapi-results`
--

DROP TABLE IF EXISTS `bananaapi-results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bananaapi-results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(25) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sms` varchar(200) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `Sender_n` varchar(25) NOT NULL,
  `taked` tinyint NOT NULL DEFAULT '0',
  `taked_time` timestamp NULL DEFAULT NULL,
  `application` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phone_number` (`phone_number`),
  KEY `timestamp` (`timestamp`),
  KEY `taked` (`taked`),
  KEY `application` (`application`)
) ENGINE=InnoDB AUTO_INCREMENT=13885111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bananaapi_number_history`
--

DROP TABLE IF EXISTS `bananaapi_number_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bananaapi_number_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` bigint NOT NULL,
  `country_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'any',
  `taked` tinyint NOT NULL DEFAULT '0',
  `createdTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `multiapp` tinyint NOT NULL DEFAULT '0',
  `taked_time` timestamp NULL DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  `is_finished` tinyint NOT NULL DEFAULT '0',
  `is_finished_time` timestamp NULL DEFAULT NULL,
  `requested` int NOT NULL DEFAULT '0',
  `release_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phone_number` (`phone_number`),
  KEY `country_code` (`country_code`),
  KEY `source` (`source`),
  KEY `application` (`application`),
  KEY `taked` (`taked`),
  KEY `release_time` (`release_time`),
  KEY `taked_2` (`taked`),
  KEY `type` (`type`),
  KEY `createdTime` (`createdTime`)
) ENGINE=InnoDB AUTO_INCREMENT=28985678 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `channels_api`
--

DROP TABLE IF EXISTS `channels_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels_api` (
  `Id_channel_Api` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(150) NOT NULL,
  `code` varchar(150) NOT NULL,
  `price_in` float NOT NULL,
  `price_out` float NOT NULL,
  `acc_price_out` float NOT NULL DEFAULT '0',
  `max_numbers` int NOT NULL DEFAULT '999',
  `availability` int NOT NULL DEFAULT '9999',
  `Modification_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` text,
  `country` varchar(45) NOT NULL,
  `country_name` varchar(64) NOT NULL,
  `service_of_api` varchar(64) DEFAULT NULL,
  `country_of_api` varchar(64) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id_channel_Api`),
  KEY `code` (`code`,`price_in`,`price_out`,`country_name`,`service_of_api`,`country_of_api`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `channels_log`
--

DROP TABLE IF EXISTS `channels_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels_log` (
  `Id_request` int NOT NULL AUTO_INCREMENT,
  `Id_user` int NOT NULL,
  `Id_Token` int NOT NULL,
  `Status` varchar(200) NOT NULL,
  `quantity` bigint DEFAULT NULL,
  `quantitydone` int NOT NULL DEFAULT '0',
  `info` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `result_link` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `TimeStmp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CC` int NOT NULL,
  `service` int NOT NULL,
  `srv_req_id` varchar(128) DEFAULT NULL,
  `return_count` int DEFAULT NULL,
  `down_state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id_request`),
  KEY `Id_user` (`Id_user`),
  KEY `Id_Token` (`Id_Token`),
  KEY `service` (`service`),
  KEY `TimeStmp` (`TimeStmp`),
  KEY `Status` (`Status`),
  KEY `srv_req_id` (`srv_req_id`)
) ENGINE=InnoDB AUTO_INCREMENT=634 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cms_users`
--

DROP TABLE IF EXISTS `cms_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_users` (
  `Id_User` int NOT NULL AUTO_INCREMENT,
  `email` varchar(64) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Passwd` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Privileges` int DEFAULT NULL,
  `is_super` int NOT NULL DEFAULT '0',
  `Is_Activated` int NOT NULL,
  `is_deleted` int NOT NULL DEFAULT '0',
  `token` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `balance` bigint DEFAULT '0',
  PRIMARY KEY (`Id_User`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`mixsimverify`@`localhost`*/ /*!50003 TRIGGER `before_insert_cms_users` BEFORE INSERT ON `cms_users` FOR EACH ROW BEGIN
  IF new.token IS NULL THEN
    SET new.token = replace(uuid(),'-','');
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `countries_control`
--

DROP TABLE IF EXISTS `countries_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries_control` (
  `country_id` int NOT NULL,
  `source` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `country` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `country_char` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `country_code` int DEFAULT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  `start` time DEFAULT '00:00:00',
  `stop` time DEFAULT '00:00:00',
  `mstart` int NOT NULL DEFAULT '0',
  `mstop` int NOT NULL DEFAULT '0',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reactivate` int NOT NULL DEFAULT '0',
  `application` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT 'whatsapp',
  UNIQUE KEY `country_id` (`country_id`,`source`),
  KEY `country_char` (`country_char`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `countryList`
--

DROP TABLE IF EXISTS `countryList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countryList` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country` varchar(64) NOT NULL,
  `country_code` int NOT NULL,
  `country_char` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country` (`country`,`country_code`,`country_char`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_stats`
--

DROP TABLE IF EXISTS `country_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_stats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country` varchar(150) NOT NULL,
  `country_char` varchar(5) NOT NULL,
  `country_code` int NOT NULL,
  `has_sms` int NOT NULL,
  `no_sms` int NOT NULL,
  `requested` int NOT NULL,
  `servertime` varchar(80) NOT NULL,
  `source` varchar(100) NOT NULL,
  `start` varchar(25) NOT NULL,
  `status` int NOT NULL,
  `stop` varchar(25) NOT NULL,
  `total` int NOT NULL,
  `Mstop` int NOT NULL,
  `Mstart` int NOT NULL,
  `available` int NOT NULL,
  `pushtime` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `row_key` (`country`,`source`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf32;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_stats1`
--

DROP TABLE IF EXISTS `country_stats1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_stats1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country` varchar(150) NOT NULL,
  `country_char` varchar(5) NOT NULL,
  `country_code` int NOT NULL,
  `has_sms` int NOT NULL,
  `no_sms` int NOT NULL,
  `requested` int NOT NULL,
  `servertime` varchar(80) NOT NULL,
  `source` varchar(100) NOT NULL,
  `start` varchar(25) NOT NULL,
  `status` int NOT NULL,
  `stop` varchar(25) NOT NULL,
  `total` int NOT NULL,
  `Mstop` int NOT NULL,
  `Mstart` int NOT NULL,
  `available` int NOT NULL,
  `pushtime` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `row_key` (`country`,`source`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf32;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cust_cntry_perm`
--

DROP TABLE IF EXISTS `cust_cntry_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_cntry_perm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usertoken` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_country` (`usertoken`,`country`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8567 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `error_log`
--

DROP TABLE IF EXISTS `error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `error_log` (
  `error_id` int NOT NULL,
  `error_code` varchar(45) DEFAULT NULL,
  `error_desc` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `finance_accounts`
--

DROP TABLE IF EXISTS `finance_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `finance_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) NOT NULL,
  `account_balance` float NOT NULL DEFAULT '0',
  `reference_api_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_balance` (`account_balance`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `foreignapi`
--

DROP TABLE IF EXISTS `foreignapi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foreignapi` (
  `Id_Api` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Access_Token` varchar(500) NOT NULL,
  `Refresh_Token` varchar(500) NOT NULL,
  `Valid` tinyint(1) NOT NULL,
  `ExpiryDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `priority` int NOT NULL DEFAULT '99',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id_Api`),
  KEY `Access_Token` (`Access_Token`,`Refresh_Token`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `foreignapiservice`
--

DROP TABLE IF EXISTS `foreignapiservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foreignapiservice` (
  `Id_Service_Api` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(150) NOT NULL,
  `code` varchar(150) NOT NULL,
  `price_in` float NOT NULL,
  `price_out` float NOT NULL,
  `acc_price_out` float NOT NULL DEFAULT '0',
  `max_numbers` int NOT NULL DEFAULT '999',
  `availability` int NOT NULL DEFAULT '9999',
  `Id_Foreign_Api` int NOT NULL,
  `Modification_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` text,
  `country` varchar(45) NOT NULL,
  `country_name` varchar(64) NOT NULL,
  `carrier` varchar(45) DEFAULT NULL,
  `service_of_api` varchar(64) DEFAULT NULL,
  `country_of_api` varchar(64) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id_Service_Api`),
  KEY `Id_Foreign_Api` (`Id_Foreign_Api`),
  KEY `code` (`code`,`price_in`,`price_out`,`Id_Foreign_Api`,`country_name`,`carrier`,`service_of_api`,`country_of_api`),
  KEY `Name` (`Name`),
  KEY `country` (`country`),
  KEY `idx_covering` (`Id_Foreign_Api`,`country`,`code`),
  CONSTRAINT `foreignapiservice_ibfk_1` FOREIGN KEY (`Id_Foreign_Api`) REFERENCES `foreignapi` (`Id_Api`)
) ENGINE=InnoDB AUTO_INCREMENT=145438 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jikatel_partnerResults`
--

DROP TABLE IF EXISTS `jikatel_partnerResults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jikatel_partnerResults` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(64) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sms` varchar(350) NOT NULL,
  `code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `application` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Sender_n` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `taked` int NOT NULL DEFAULT '0',
  `taked_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `smsId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1391 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manual_numbers`
--

DROP TABLE IF EXISTS `manual_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manual_numbers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(64) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `taked` tinyint NOT NULL DEFAULT '0',
  `taked_time` timestamp NULL DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `country_char` varchar(4) DEFAULT NULL,
  `sms_code` varchar(16) DEFAULT NULL,
  `application` varchar(16) NOT NULL DEFAULT 'wa',
  `taked_sms` int NOT NULL DEFAULT '0',
  `sms_code_time` timestamp NULL DEFAULT NULL,
  `sms_taked_time` timestamp NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `paid` int NOT NULL DEFAULT '0',
  `wrong_code` int NOT NULL DEFAULT '0',
  `deleted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone_number` (`phone_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `number_waiting_list`
--

DROP TABLE IF EXISTS `number_waiting_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `number_waiting_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` bigint NOT NULL,
  `country_code` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `source` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `createdtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `phone_number_2` (`phone_number`),
  KEY `country_code` (`country_code`),
  KEY `source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number_count` int NOT NULL,
  `country_id` int NOT NULL,
  `number_of_threads` int NOT NULL,
  `status` int NOT NULL,
  `created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `started_at` timestamp NULL DEFAULT NULL,
  `finished_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_gateway`
--

DROP TABLE IF EXISTS `payment_gateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateway` (
  `gate_id` int NOT NULL,
  `payment_gatewaycol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`gate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recharge`
--

DROP TABLE IF EXISTS `recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge` (
  `recharge_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `recharge_date` datetime DEFAULT NULL,
  `gate_id` int DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`recharge_id`),
  KEY `gate_id_idx` (`gate_id`),
  KEY `customer_id_idx` (`customer_id`),
  CONSTRAINT `customer_id` FOREIGN KEY (`customer_id`) REFERENCES `users` (`Id`),
  CONSTRAINT `gate_id` FOREIGN KEY (`gate_id`) REFERENCES `payment_gateway` (`gate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=423 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redis_numbers`
--

DROP TABLE IF EXISTS `redis_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redis_numbers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `phone_number` bigint NOT NULL,
  `country_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'whatsapp',
  `taked` tinyint NOT NULL DEFAULT '0',
  `createdTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `multiapp` tinyint NOT NULL DEFAULT '0',
  `taked_time` timestamp NULL DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  `is_finished` tinyint NOT NULL DEFAULT '0',
  `is_finished_time` timestamp NULL DEFAULT NULL,
  `requested` int NOT NULL DEFAULT '0',
  `release_time` timestamp NULL DEFAULT NULL,
  `flag` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phone_number` (`phone_number`),
  KEY `country_code` (`country_code`),
  KEY `source` (`source`),
  KEY `application` (`application`),
  KEY `taked` (`taked`),
  KEY `createdTime` (`createdTime`),
  KEY `flag` (`flag`),
  KEY `idx_fk_foreignapiservice` (`application`,`country_code`),
  KEY `idx_fk_countries_control` (`country_code`,`source`)
) ENGINE=InnoDB AUTO_INCREMENT=17064785563743 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `requests_log`
--

DROP TABLE IF EXISTS `requests_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requests_log` (
  `Id_request` int NOT NULL AUTO_INCREMENT,
  `Id_user` int NOT NULL,
  `Id_Token` int NOT NULL,
  `Status` varchar(200) NOT NULL,
  `Phone_Nb` bigint DEFAULT NULL,
  `SMSCode` varchar(10) DEFAULT NULL,
  `sms_content` varchar(512) DEFAULT NULL,
  `TimeStmp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CC` int NOT NULL,
  `service` int NOT NULL,
  `srv_req_id` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`Id_request`),
  KEY `Id_user` (`Id_user`),
  KEY `Id_Token` (`Id_Token`),
  KEY `service` (`service`),
  KEY `TimeStmp` (`TimeStmp`),
  KEY `Status` (`Status`),
  KEY `srv_req_id` (`srv_req_id`),
  KEY `Phone_Nb` (`Phone_Nb`),
  KEY `idx_requests_log_Id_user` (`Id_user`),
  CONSTRAINT `requests_log_ibfk_1` FOREIGN KEY (`Id_user`) REFERENCES `users` (`Id`),
  CONSTRAINT `requests_log_ibfk_2` FOREIGN KEY (`Id_Token`) REFERENCES `tokens` (`Id_Token`)
) ENGINE=InnoDB AUTO_INCREMENT=94185895 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `requests_log_history`
--

DROP TABLE IF EXISTS `requests_log_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requests_log_history` (
  `Id_request` int NOT NULL AUTO_INCREMENT,
  `Id_user` int NOT NULL,
  `Id_Token` int NOT NULL,
  `Status` varchar(200) NOT NULL,
  `Phone_Nb` bigint DEFAULT NULL,
  `SMSCode` varchar(10) DEFAULT NULL,
  `sms_content` varchar(512) DEFAULT NULL,
  `TimeStmp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CC` int NOT NULL,
  `service` int NOT NULL,
  `srv_req_id` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`Id_request`),
  UNIQUE KEY `Id_request` (`Id_request`),
  KEY `Id_user` (`Id_user`),
  KEY `Id_Token` (`Id_Token`),
  KEY `service` (`service`),
  KEY `TimeStmp` (`TimeStmp`),
  KEY `Status` (`Status`),
  KEY `srv_req_id` (`srv_req_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87241315 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tem_number`
--

DROP TABLE IF EXISTS `tem_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tem_number` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone_number` bigint NOT NULL,
  `country_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'any',
  `taked` tinyint NOT NULL DEFAULT '0',
  `createdTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `multiapp` tinyint NOT NULL DEFAULT '0',
  `taked_time` timestamp NULL DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  `is_finished` tinyint NOT NULL DEFAULT '0',
  `is_finished_time` timestamp NULL DEFAULT NULL,
  `requested` int NOT NULL DEFAULT '0',
  `release_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phone_number` (`phone_number`),
  KEY `country_code` (`country_code`),
  KEY `source` (`source`),
  KEY `application` (`application`),
  KEY `taked` (`taked`),
  KEY `createdTime` (`createdTime`)
) ENGINE=InnoDB AUTO_INCREMENT=38099373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `th_countrylist`
--

DROP TABLE IF EXISTS `th_countrylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `th_countrylist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country_code` int NOT NULL,
  `country_char` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `country_name` varchar(300) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=699 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `Id_Token` int NOT NULL AUTO_INCREMENT,
  `userID` int NOT NULL,
  `access_Token` varchar(500) NOT NULL,
  `expiry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Valid` tinyint(1) NOT NULL,
  `Tag` varchar(500) NOT NULL,
  `re` varchar(64) NOT NULL DEFAULT 'UUID()',
  PRIMARY KEY (`Id_Token`),
  KEY `users_to_tokens` (`userID`),
  KEY `Id_Token` (`Id_Token`,`userID`,`access_Token`,`expiry_date`,`Valid`),
  CONSTRAINT `users_to_tokens` FOREIGN KEY (`userID`) REFERENCES `users` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `transactionID` int NOT NULL AUTO_INCREMENT,
  `customerID` int NOT NULL,
  `debit` decimal(10,2) NOT NULL,
  `credit` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  `notes` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `transDate` date NOT NULL,
  `transCommitDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fapi_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`transactionID`),
  KEY `customerID` (`customerID`,`debit`,`credit`,`transDate`,`fapi_id`),
  KEY `transDate` (`transDate`,`transCommitDateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=399496671 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `upload_user`
--

DROP TABLE IF EXISTS `upload_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `upload_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `user_pass` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_roll` int NOT NULL DEFAULT '2',
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_allowed_api`
--

DROP TABLE IF EXISTS `user_allowed_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_allowed_api` (
  `ua_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `api_id` int NOT NULL,
  PRIMARY KEY (`ua_id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_countries`
--

DROP TABLE IF EXISTS `user_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_countries` (
  `user_id` int NOT NULL,
  `country_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19575 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_login_log`
--

DROP TABLE IF EXISTS `user_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_login_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `uip` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1983 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_stat`
--

DROP TABLE IF EXISTS `user_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_stat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(500) COLLATE utf8mb4_bin NOT NULL,
  `passw` varchar(500) COLLATE utf8mb4_bin NOT NULL,
  `token` varchar(500) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `passwd` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(127) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activation_key` varchar(50) NOT NULL,
  `Is_Activated` tinyint(1) NOT NULL DEFAULT '0',
  `Balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_refunding` tinyint(1) NOT NULL DEFAULT '0',
  `callback_url` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `callback_status` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `email` (`email`),
  KEY `Balance` (`Balance`),
  KEY `admin_id` (`admin_id`),
  KEY `callback_status` (`callback_status`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'smsdb'
--
/*!50003 DROP FUNCTION IF EXISTS `check_serviceAndBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` FUNCTION `check_serviceAndBalance`(`token` VARCHAR(64), `srv_code` VARCHAR(10), `srv_country` VARCHAR(50), `srv_carrier` VARCHAR(10)) RETURNS varchar(50) CHARSET latin1
BEGIN
declare userBalance  decimal(10,2);
declare serviceCost  decimal(10,2);
 SELECT `price_out` INTO serviceCost from `foreignapiservice`  where `country`=srv_country and `carrier` =srv_carrier and `code`=srv_code;
SELECT  `Balance` INTO userBalance from `tokens`,`users` where `userID`=`Id` and  `access_token`=token;
IF isnull(serviceCost) THEN
   return "error no service";
ELSEif serviceCost > userBalance then
    return concat("error balance not enough: cost: ",serviceCost," balance: ",userBalance);
else
    return "ok";
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `check_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` FUNCTION `check_token`(`param` VARCHAR(127)) RETURNS varchar(50) CHARSET latin1
BEGIN
  DECLARE validity int;
  DECLARE u_balance  decimal(10,2);
  declare uid int;
  SELECT `valid` ,`userID` INTO validity, uid FROM `tokens`    WHERE `access_token` = param limit 1;
if isnull(validity) THEN
        return "error: unvalid token";
else
        SELECT `users`.`Balance` into u_balance FROM  `users`  where `Id`=uid  ;
    if u_balance <= 0 then
                return "error: zero balance";
    else
                return u_balance;
    end if ;
END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_Balance_with_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `check_Balance_with_count`(IN `token` VARCHAR(127), IN `quantity` INT)
BEGIN
declare userBalance decimal(10,2);
declare serviceCost  decimal(10,2);
 SELECT `price_out`   INTO serviceCost   from `channels_api` LIMIT 1;
SELECT  `Balance` INTO userBalance from `tokens`,`users` where `userID`=`Id` and  `access_token`=token limit 1;
IF isnull(serviceCost) THEN
   select  "error no service" as 'flag';
ELSEif (serviceCost*quantity) > userBalance then
    select  concat("error balance not enough: cost: ",serviceCost," balance: ",userBalance) as 'flag';
else
    select "ok" as 'flag', (serviceCost*quantity) as 'cost',userBalance as 'balance' ;

END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_req_owner_ret_fapi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `check_req_owner_ret_fapi`(IN `req_id` INT, IN `token` VARCHAR(64))
    NO SQL
BEGIN
declare req_tok_id int;
declare token_id int;
declare service_ int;
declare fapi_id int ;
declare srv_req_id_ int;
declare status_ varchar(10);
select `Id_Token` ,`service` ,`srv_req_id` ,`Status` into req_tok_id ,service_ ,srv_req_id_ ,status_
from requests_log where `Id_request` =req_id;
select `Id_Token` into token_id from tokens where `access_Token`=token;
if (req_tok_id=token_id )then
    select `Id_Foreign_Api` into fapi_id from foreignapiservice where `Id_Service_Api`=service_;
        select 1 as 'allow',fapi_id as 'fapi' ,srv_req_id_ as `srv_req_id` ,status_ as "Status";
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_serviceAndBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `check_serviceAndBalance`(IN `token` VARCHAR(127), IN `srv_code` VARCHAR(10), IN `srv_country` VARCHAR(50), IN `srv_carrier` VARCHAR(10))
BEGIN
declare userBalance decimal(10,2);
declare serviceCost  decimal(10,2);
declare fapi_id int;
declare serv_id int;
declare country_of_api_ varchar(20);
declare service_of_api_ varchar(20);
declare carrier_ varchar(20) ;
 SELECT `price_out`, `Id_Foreign_Api` ,`Id_Service_Api` ,`country_of_api`,`service_of_api` ,`carrier` INTO serviceCost ,fapi_id ,serv_id ,country_of_api_, service_of_api_  ,carrier_ from `foreignapiservice`  where `country`=srv_country and `carrier` =srv_carrier and `code`=srv_code LIMIT 1;
SELECT  `Balance` INTO userBalance from `tokens`,`users` where `userID`=`Id` and  `access_token`=token limit 1;
IF isnull(serviceCost) THEN
   select  "error no service" as 'flag';
ELSEif serviceCost > userBalance then
    select  concat("error balance not enough: cost: ",(serviceCost*1)," balance: ",userBalance) as 'flag';
else
    select "ok" as 'flag',fapi_id as 'fapi_id',serv_id as 'serv_id' ,serviceCost as 'cost',userBalance as 'balance',
 country_of_api_ as 'country_of_api' ,  service_of_api_  as 'service_of_api' , carrier_ as 'carrier'
    ;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_applist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `get_applist`()
BEGIN
   SELECT  `code`,`Name`,`country`,`price_out` as 'cost' FROM foreignapiservice where `Id_Foreign_Api` = 17
   group by `code`,`Name`,`country`,`cost`
   ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_code` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `get_code`(IN `req_id` INT, IN `token` VARCHAR(255))
    NO SQL
BEGIN
declare sms_code varchar(10);
declare req_tok_id int;
declare token_id int;
declare fsrv_req_id varchar(255);
declare sms_content_ varchar(255);
declare foreign_id int;
declare service_id int;

select `Id_Token` ,`SMSCode`, `srv_req_Id`,`service`,`sms_content`
into
req_tok_id ,sms_code,fsrv_req_id,service_id,sms_content_

from requests_log where `Id_request` =req_id;
select `Id_Token` into token_id
from tokens where `access_Token`=token;
select `Id_Foreign_Api` into foreign_id from foreignapiservice where `Id_Service_Api` =service_id;

if (req_tok_id=token_id )then
        select 1 as 'allow',
                sms_code as 'code',
            sms_content_ as 'sms_content',
            fsrv_req_id as 'srv_req_id' ,
            foreign_id as 'foreign_id'

            ;
else
        select 0 as 'allow', "error:wrong request id" as 'code';
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_refund` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `get_refund`(IN `req_id` INT, IN `access` VARCHAR(64))
    NO SQL
BEGIN

declare cust_id  int;
declare token_id varchar(255);
declare status_ varchar(255);
declare price_out_  decimal(10,2);
declare serv_country varchar(255);
declare serv_carrier varchar(255);
declare last_id int;
declare price_in_  decimal(10,2);
declare fapi_id_ int;
declare service_id int;
declare req_tok_id int;
select   `Id_Token`           into req_tok_id             from requests_log    where `Id_request` =req_id;
select   `userID`,`Id_Token`  INTO cust_id , token_id     from `tokens`        where `access_token`=access;
if(req_tok_id=token_id) then
    SELECT `price_in`, `price_out`,`country`,`carrier` ,`Id_Foreign_Api` ,`service`,`Status`
    INTO price_in_,price_out_ , serv_country , serv_carrier ,fapi_id_ ,service_id , status_
    from `foreignapiservice` ,`requests_log` where `Id_Service_Api`=`service` and `Id_request`=req_id limit 1;
     if(status_='pending') then
        update `users` set `balance`=`balance`+ price_out_ where `Id`= cust_id ;

        update `finance_accounts` set `account_balance`=`account_balance`- (price_out_- price_in_) where `id`= 1 ;
        update `finance_accounts` set `account_balance`=`account_balance`+ price_in_ where `reference_api_id`= fapi_id_ ;

        INSERT INTO `transaction`
        (`customerID`,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
        VALUES
        (cust_id ,price_out_,0,concat('Refund number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );


        INSERT INTO `transaction`
        (`fapi_id`, `customerID` ,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
        VALUES
        (fapi_id_ ,0,0,price_in_,concat('Refund number from service ',service_id," ",serv_country,"-",serv_carrier),req_id,CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );


        update `requests_log` set `Status`='Expired' where `Id_request`= req_id;
        select LAST_INSERT_ID() into last_id;
        select 'OK' as 'flag',price_out_ as 'refund' ,'success' as 'Msg';
    else
        select 'error' as 'flag',0.00   as 'refund' ,'Already expired' as 'Msg';
   end if;
else
     select 'error' as 'flag',0.00   as 'refund' ,'wrong input data' as 'Msg';
end if ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PerformRecharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `PerformRecharge`(IN `p_user_id` INT, IN `p_amount` FLOAT, IN `p_gift` FLOAT, IN `p_is_super` INT, IN `p_admin_id` INT)
BEGIN
    DECLARE v_admin_balance FLOAT;
    DECLARE v_admin_id INT;
    DECLARE v_user_balance FLOAT;
    DECLARE v_typ VARCHAR(255);
    DECLARE v_desc VARCHAR(255);

    SET v_typ = 'Real';
    SET v_desc = 'Customer recharge Real';

    IF p_amount < 0 THEN
        SET v_typ = 'Reduction';
        SET v_desc = 'Administration reduction';
    END IF;

    START TRANSACTION;

    IF p_is_super != 1 THEN
        SELECT balance INTO v_admin_balance FROM cms_users WHERE Id_User = p_user_id FOR UPDATE;

        IF v_admin_balance < ABS(p_amount) THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'NoBalance';
        END IF;

        SELECT adminId INTO v_admin_id FROM users  WHERE Id = p_user_id FOR UPDATE; 
        IF adminId != p_admin_id THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'AccessDeniedUser';
        END IF;
    END IF;

    IF p_amount < 0 THEN
        SELECT Balance INTO v_user_balance FROM users WHERE Id = p_user_id FOR UPDATE;

        IF ABS(p_amount) > v_user_balance THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'NoBalance';
        END IF;
    END IF;

    UPDATE users SET `Balance` = `Balance` + p_amount WHERE Id = p_user_id;

    IF p_is_super != 1 THEN
        IF p_amount < 0 THEN
            UPDATE cms_users SET `balance` = `balance` + ABS(p_amount) WHERE Id_User = p_user_id;
        ELSE
            UPDATE cms_users SET `balance` = `balance` - p_amount WHERE Id_User = p_user_id;
        END IF;

        SET v_desc = 'administration discount';

        INSERT INTO `transaction`(`customerID`, `debit`, `credit`, `description`, `notes`, `fapi_id`, `transDate`)
        VALUES (p_user_id, 0, ABS(p_amount), v_desc, '', 0, NOW());
    END IF;

    INSERT INTO `recharge`(`customer_id`, `amount`, `recharge_date`, `gate_id`, `type`)
    VALUES (p_user_id, p_amount, NOW(), 1, v_typ);

    INSERT INTO `transaction`(`customerID`, `debit`, `credit`, `description`, `notes`, `fapi_id`, `transDate`)
    VALUES (p_user_id, p_amount, 0, v_desc, '', 0, NOW());

    IF p_gift != 0 AND p_is_super = 1 THEN
        UPDATE users SET `Balance` = `Balance` + p_gift WHERE Id = p_user_id;

        INSERT INTO `recharge`(`customer_id`, `amount`, `recharge_date`, `gate_id`, `type`)
        VALUES (p_user_id, p_gift, NOW(), 1, 'Gift');

        INSERT INTO `transaction`(`customerID`, `debit`, `credit`, `description`, `notes`, `fapi_id`, `transDate`)
        VALUES (p_user_id, p_gift, 0, 'Customer recharge gift', '', 0, NOW());
    END IF;

    COMMIT;

    SELECT 'Success' AS status;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `purchasePro2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `purchasePro2`(IN `access` VARCHAR(255), IN `service_id` INT, IN `pdata` TEXT)
BEGIN
   declare price_out_ decimal(10,2); 
   declare cust_id int;
   declare token_id varchar(255);
   declare serv_country varchar(255);
   declare serv_carrier varchar(255);
   declare last_id int;
   declare numbers_count int;
   declare price_in_ decimal(10,2);
   declare fapi_id_ int;
   declare lastInsertId int;

   DECLARE idx INT DEFAULT 0;
   DECLARE currentData JSON;
   DECLARE resultJsonArray JSON DEFAULT JSON_ARRAY();

   select  `userID`,`Id_Token` INTO cust_id , token_id from `tokens` where `access_token`=access;

   SELECT `price_in`, `price_out`,`country`,`carrier` ,`Id_Foreign_Api` 
   INTO price_in_,price_out_ , serv_country , serv_carrier ,fapi_id_
   from `foreignapiservice` where `Id_Service_Api`=service_id;
   SET numbers_count = JSON_LENGTH(pdata);
   update `users` set `balance`=`balance`- (price_out_ * numbers_count) where `Id`= cust_id ;
   update `finance_accounts` set `account_balance`=`account_balance`+ ((price_out_ - price_in_)*numbers_count) where `id`= 1 ;
   update `finance_accounts` set `account_balance`=`account_balance`- (price_in_*numbers_count) where `reference_api_id`= fapi_id_ ;

       INSERT INTO `transaction`
       (`customerID`,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
       VALUES
       (cust_id ,0,(price_out_*numbers_count),concat('get number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );

       INSERT INTO `transaction`
       (`fapi_id`, `customerID` ,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
       VALUES
       (fapi_id_ ,0,(price_in_*numbers_count),0,concat('get number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );

       
   WHILE idx < numbers_count DO
       SET currentData = JSON_EXTRACT(pdata, CONCAT('$[', idx, ']'));
        INSERT INTO `requests_log`
            (`Id_user`,`Id_Token`,`Status`,`Service`,`srv_req_Id`,`TimeStmp`,`CC`,`Phone_Nb`)
       VALUES
            (cust_id ,token_id,'pending',service_id ,CAST(JSON_EXTRACT(currentData, '$.Id')AS CHAR), CURRENT_TIMESTAMP(),0,CAST(JSON_EXTRACT(currentData, '$.Number') AS CHAR));

       SET lastInsertId = LAST_INSERT_ID();
       SET resultJsonArray = JSON_ARRAY_APPEND(resultJsonArray, '$', JSON_OBJECT('id', lastInsertId, 'Number', (JSON_EXTRACT(currentData, '$.Number'))));
       SET idx = idx + 1;
   END WHILE;

   SELECT resultJsonArray AS result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `purchasePro3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `purchasePro3`(IN `access` VARCHAR(255), IN `service_id` INT, IN `pdata` TEXT)
BEGIN
   declare price_out_ decimal(10,2); 
   declare cust_id int;
   declare token_id varchar(255);
   declare serv_country varchar(255);
   declare serv_carrier varchar(255);
   declare last_id int;
   declare numbers_count int;
   declare price_in_ decimal(10,2);
   declare fapi_id_ int;
   declare lastInsertId int;

   DECLARE idx INT DEFAULT 0;
   DECLARE currentData JSON;
   DECLARE resultJsonArray JSON DEFAULT JSON_ARRAY();

   select  `userID`,`Id_Token` INTO cust_id , token_id from `tokens` where `access_token`=access;

   SELECT `price_in`, `price_out`,`country`,`carrier` ,`Id_Foreign_Api` 
   INTO price_in_,price_out_ , serv_country , serv_carrier ,fapi_id_
   from `foreignapiservice` where `Id_Service_Api`=service_id;
   SET numbers_count = JSON_LENGTH(pdata);
   update `users` set `balance`=`balance`- (price_out_ * numbers_count) where `Id`= cust_id ;
   update `finance_accounts` set `account_balance`=`account_balance`+ ((price_out_ - price_in_)*numbers_count) where `id`= 1 ;
   update `finance_accounts` set `account_balance`=`account_balance`- (price_in_*numbers_count) where `reference_api_id`= fapi_id_ ;

   WHILE idx < numbers_count DO
       SET currentData = JSON_EXTRACT(pdata, CONCAT('$[', idx, ']'));

       INSERT INTO `transaction`
       (`customerID`,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
       VALUES
       (cust_id ,0,price_out_,concat('get number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );

       INSERT INTO `transaction`
       (`fapi_id`, `customerID` ,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
       VALUES
       (fapi_id_ ,0,price_in_,0,concat('get number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );

       INSERT INTO `requests_log`
       (`Id_user`,`Id_Token`,`Status`,`Service`,`srv_req_Id`,`TimeStmp`,`CC`,`Phone_Nb`)
       VALUES
        ( cust_id ,token_id,'pending',service_id ,CAST(JSON_EXTRACT(currentData, '$.Id')AS CHAR), CURRENT_TIMESTAMP(),0,CAST(JSON_EXTRACT(currentData, '$.Number') AS CHAR));

       SET lastInsertId = LAST_INSERT_ID();
       SET resultJsonArray = JSON_ARRAY_APPEND(resultJsonArray, '$', JSON_OBJECT('id', lastInsertId, 'Number', (JSON_EXTRACT(currentData, '$.Number') )));
       SET idx = idx + 1;
   END WHILE;

   SELECT resultJsonArray AS result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `purchaseProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `purchaseProcedure`(IN `access` VARCHAR(255), IN `service_id` INT, IN `sreq_id` VARCHAR(128), IN `phone_num` VARCHAR(20))
BEGIN
declare price_out_  decimal(10,2);
declare cust_id  int;
declare token_id varchar(255);
declare serv_country varchar(255);
declare serv_carrier varchar(255);
declare last_id int;
declare price_in_  decimal(10,2);
declare fapi_id_ int;
select   `userID`,`Id_Token`  INTO cust_id , token_id  from `tokens`  where `access_token`=access;
SELECT `price_in`, `price_out`,`country`,`carrier` ,`Id_Foreign_Api`
INTO price_in_,price_out_ , serv_country , serv_carrier ,fapi_id_
from `foreignapiservice`  where `Id_Service_Api`=service_id;
update `users` set `balance`=`balance`- price_out_ where `Id`= cust_id ;
update `finance_accounts` set `account_balance`=`account_balance`+ (price_out_ - price_in_) where `id`= 1 ;
update `finance_accounts` set `account_balance`=`account_balance`- price_in_ where `reference_api_id`= fapi_id_ ;

INSERT INTO `transaction`
(`customerID`,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
VALUES
 (cust_id ,0,price_out_,concat('get number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );


 INSERT INTO `transaction`
(`fapi_id`, `customerID` ,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
VALUES
 (fapi_id_ ,0,price_in_,0,concat('get number from service ',service_id," ",serv_country,"-",serv_carrier),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );


 INSERT INTO `requests_log`
(`Id_user`,`Id_Token`,`Status`,`Service`,`srv_req_Id`,`TimeStmp`,`CC`,`Phone_Nb`)
VALUES
( cust_id ,token_id,'pending',service_id ,sreq_id, CURRENT_TIMESTAMP,0,phone_num);

select LAST_INSERT_ID() into last_id;
select 'OK' as 'flag',last_id as 'reqId';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `purchase_channels` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`mixsimverify`@`localhost` PROCEDURE `purchase_channels`(IN `access` VARCHAR(255), IN `sreq_id` VARCHAR(128), IN `quantity` INT, IN `country` VARCHAR(20))
BEGIN
declare price_out_  decimal(10,2);
declare cust_id  int;
declare token_id varchar(255);
declare last_id int;
declare price_in_  decimal(10,2);

select   `userID`,`Id_Token`  INTO cust_id , token_id  from `tokens`  where `access_token`=access;
SELECT `price_in`, `price_out`  INTO price_in_,price_out_   from `channels_api`  limit 1;

update `users` set `balance`=`balance`- (price_out_*quantity) where `Id`= cust_id ;

update `finance_accounts` set `account_balance`=`account_balance`+ ((price_out_*quantity) - (price_in_*quantity)) where `id`= 1 ;
update `finance_accounts` set `account_balance`=`account_balance`- (price_in_*quantity) where `account_name`= 'china_old_channels' ;

INSERT INTO `transaction`
(`customerID`,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
VALUES
 (cust_id ,0,(price_out_*quantity),concat('get ',quantity,' channels from china_old_channels country ',country),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );


 INSERT INTO `transaction`
(`fapi_id`, `customerID` ,`debit`,`credit`,`description`,`notes`,`transDate`,`transCommitDateTime` )
VALUES
 (15 ,0,(price_in_*quantity),0,concat('get ',quantity,'channles from china_old_channels'),'',CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP );


 INSERT INTO `channels_log`
(`Id_user`,`Id_Token`,`Status`,`Service`,`srv_req_Id`,`TimeStmp`,`CC`,`quantity`,`info`)
VALUES
( cust_id ,token_id,'pending',1 ,sreq_id, CURRENT_TIMESTAMP,0,quantity,country);

select LAST_INSERT_ID() into last_id;
select 'OK' as 'flag',last_id as 'reqId';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-28 21:49:38
-- MySQL dump 10.13  Distrib 8.0.34-26, for Linux (x86_64)
--
-- Host: 192.168.100.20    Database: smsdb
-- ------------------------------------------------------
-- Server version	8.0.34-26.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Dumping data for table `application_code`
--
-- WHERE:  1=0

LOCK TABLES `application_code` WRITE;
/*!40000 ALTER TABLE `application_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `countryList`
--
-- WHERE:  1=0

LOCK TABLES `countryList` WRITE;
/*!40000 ALTER TABLE `countryList` DISABLE KEYS */;
/*!40000 ALTER TABLE `countryList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `finance_accounts`
--
-- WHERE:  1=0

LOCK TABLES `finance_accounts` WRITE;
/*!40000 ALTER TABLE `finance_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `finance_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `foreignapi`
--
-- WHERE:  1=0

LOCK TABLES `foreignapi` WRITE;
/*!40000 ALTER TABLE `foreignapi` DISABLE KEYS */;
/*!40000 ALTER TABLE `foreignapi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `foreignapiservice`
--
-- WHERE:  1=0

LOCK TABLES `foreignapiservice` WRITE;
/*!40000 ALTER TABLE `foreignapiservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `foreignapiservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payment_gateway`
--
-- WHERE:  1=0

LOCK TABLES `payment_gateway` WRITE;
/*!40000 ALTER TABLE `payment_gateway` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_gateway` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-28 21:49:38
